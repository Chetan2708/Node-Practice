const express = require("express");
const fs = require("fs");

const app = express();

app.use(express.json()); // middleware for json body , use req.body directly no need to extract

app.get("/", function (req, res) {
  res.sendFile(__dirname + "/todo_app/index.html");
});

app.post("/todo", function (req, res) {
  saveTodoInFile(req.body, function (err) {
    if (err) {
      res.status(500).send("error");
      return;
    }

    res.status(200).send("success");
  });
});

app.get("/todo-data", function (req, res) {
  readAllTodos(function (err, data) {
    if (err) {
      res.status(500).send("error");
      return;
    }

    //res.status(200).send(JSON.stringify(data));
    res.status(200).json(data);
  });
});
app.get("/about", function (req, res) {
  res.sendFile(__dirname + "/todo_app/about.html");
});

app.get("/contact", function (req, res) {
  res.sendFile(__dirname + "/todo_app/contact.html");
});

app.get("/todo", function (req, res) {
  res.sendFile(__dirname + "/todo_app/todo.html");
});

app.get("/todoScript.js", function (req, res) {
  res.sendFile(__dirname + "/todo_app/script/todoScript.js");
});

app.listen(8000, function () {
  console.log("server on port 8000");
});

app.put("/todo/:id", function (req, res) {
  const todoId = req.params.id;
  const data = JSON.parse(fs.readFileSync("treasure.txt", "utf8"));
  const todo = data.find((t) => t.id === parseInt(todoId));
  if (!todo) {
    return res.status(404).json({ message: "Task not found." });
  }

  todo.completed = true; // Mark the task as completed

  fs.writeFileSync("treasure.txt", JSON.stringify(data, null, 2));
  res.sendStatus(200);
});

app.delete("/todo/:id", function (req, res) {
  const todoId = req.params.id;
  const data = JSON.parse(fs.readFileSync("treasure.txt", "utf8"));
  const newData = data.filter((t) => t.id !== parseInt(todoId));

  if (data.length === newData.length) {
    return res.status(404).json({ message: "Task not found." });
  }

  fs.writeFileSync("treasure.txt", JSON.stringify(newData, null, 2));
  res.sendStatus(200);
});

//Read the file first

function readAllTodos(callback) {
  fs.readFile("./treasure.txt", "utf-8", function (err, data) {
    if (err) {
      callback(err);
      return;
    }

    if (data.length === 0) {
      data = "[]";
    }

    try {
      data = JSON.parse(data);
      callback(null, data);
    } catch (err) {
      callback(err);
    }
  });
}

function saveTodoInFile(todo, callback) {
  readAllTodos(function (err, data) {
    if (err) {
      callback(err);
      return;
    }

    data.push(todo);

    fs.writeFile("./treasure.txt", JSON.stringify(data), function (err) {
      if (err) {
        callback(err);
        return;
      }

      callback(null);
    });
  });
}
