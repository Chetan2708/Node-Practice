const submitTodoNode = document.getElementById("submitTodo");
const InputNode = document.getElementById("userInput");
const prioritySelector = document.getElementById("prioritySelector");
const todoListNode = document.getElementById("todo-item");


submitTodoNode.addEventListener("click", function () {
  const InputValue = InputNode.value;
  const priority = prioritySelector.value;

  if (!InputValue || !priority) {
    alert("Please enter value");
    return;
  }

  const uniqueId = Date.now();
  const todo = {
    id: uniqueId,
    InputValue,
    priority,
  };

  fetch("/todo", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(todo),
  }).then(function (response) {
    if (response.status === 200) {
      // Display todo in UI
      showTodoInUI(todo);
      InputNode.value = "";
    } else {
      alert("Something went wrong");
    }
  });
});

function showTodoInUI(todo) {
  const todoContainer = document.createElement("div");

  const todoTextNode = document.createElement("chetan");
  todoTextNode.innerText = `Task: ${todo.InputValue}`;

  const priorityNode = document.createElement("span");
  priorityNode.innerText = `Priority: ${todo.priority}`;

  const deleteButton = document.createElement("button");
  deleteButton.innerText = "❌";
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";

  checkbox.addEventListener("change", function () {
    if (checkbox.checked) {
      // Send a request to mark the task as completed
      fetch(`/todo/${todo.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ completed: true }),
      }).then(function (response) {
        if (response.status === 200) {
          // Add a line-through style to the task text
          todoTextNode.style.textDecoration = "line-through";
        } else {
          alert("Something went wrong while updating the task.");
        }
      });
    }
  });

  deleteButton.addEventListener("click", function () {
    // Send a request to delete the task
    fetch(`/todo/${todo.id}`, {
      method: "DELETE",
    }).then(function (response) {
      if (response.status === 200) {
        // Remove the task container from the UI
        todoContainer.remove();
      } else {
        alert("Something went wrong while deleting the task.");
      }
    });
  });

  todoContainer.appendChild(checkbox);
  todoContainer.appendChild(todoTextNode);
  todoContainer.appendChild(priorityNode);
  todoContainer.appendChild(deleteButton);

  todoListNode.appendChild(todoContainer);
}

fetch("/todo-data")
  .then(function (response) {
    if (response.status === 200) {
      return response.json();
    } else {
      alert("something weird happened");
    }
  })
  .then(function (todos) {
    todos.forEach(function (todo) {
      showTodoInUI(todo);
    });
  });
